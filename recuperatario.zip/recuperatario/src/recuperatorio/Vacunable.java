
package recuperatorio;

public interface Vacunable {

    public void vacunar();
}
