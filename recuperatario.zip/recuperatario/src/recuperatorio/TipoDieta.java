
package recuperatorio;


public enum TipoDieta {
    HERBIVORO,
    CARNIVORO,
    OMNIVORO;
    
}
