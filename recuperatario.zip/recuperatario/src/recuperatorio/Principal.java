/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recuperatorio;

public class Principal {

   
    public static void main(String[] args) {
       
        Zoologico zoo = new Zoologico();
        
        Mamifero m1 = new Mamifero(12.5, TipoDieta.HERBIVORO, "Juan", 10);
        Ave a1 = new Ave(3, "Juancho", 4);
        Reptil r1 = new Reptil("Pecoso", "Fria","Pepe", 0);
        /*Mamifero m2 = new Mamifero(10, TipoDieta.HERBIVORO, "Juan", 10);*/
        
        /* si se agrega a este animal salta el exception zoo.agregarAnimal(m2);*/
        zoo.agregarAnimal(a1);
        zoo.agregarAnimal(m1);
        zoo.agregarAnimal(r1);
        zoo.mostrarAnimal();
        a1.vacunar();
        m1.vacunar();
        r1.Vacunar();
    }
    
}
