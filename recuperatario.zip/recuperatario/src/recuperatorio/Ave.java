
package recuperatorio;


public class Ave extends Animal implements Vacunable {
    
    private double alasEnv;

    public Ave(double alasEnv, String nombre, int edad) {
        super(nombre, edad);
        this.alasEnv = alasEnv;
    }

    @Override
    public void vacunar() {
        System.out.println("Ave vacunada...");
    }

    @Override
    public String toString() {
        return "Ave{" + "alasEnv=" + alasEnv + '}';
    }
    
    
    
    
}
