
package recuperatorio;


public class AnimalDuplicadoException extends RuntimeException{
    
    private static final String MESSAGE = "El animal esta repetido";
    
    public AnimalDuplicadoException(){
        super(MESSAGE);
    }
    
}
