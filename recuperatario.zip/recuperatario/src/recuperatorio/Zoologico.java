
package recuperatorio;

import java.util.ArrayList;
import java.util.List;


public class Zoologico {
    
    private List<Animal> animales;

    public Zoologico() {
        this.animales = new ArrayList<>();
    }

    public void agregarAnimal(Animal animal) {
        if(this.animales.contains(animal)){
           throw new AnimalDuplicadoException();
        }
        this.animales.add(animal);
    }
    
    
    public void mostrarAnimal(){
        for(Animal animal : animales){
            System.out.println(animal);
        }
    }

  
    
    
}
