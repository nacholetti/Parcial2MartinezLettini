
package recuperatorio;


public class Mamifero extends Animal implements Vacunable {
    private double peso;
    private TipoDieta tipoDieta;

    public Mamifero(double peso, TipoDieta tipoDieta, String nombre, int edad) {
        super(nombre, edad);
        this.peso = peso;
        this.tipoDieta = tipoDieta;
    }

  

    @Override
    public void vacunar() {
        System.out.println("Mamifero vacunado...");
    }

    @Override
    public String toString() {
        return "Mamifero{" + "peso=" + peso + ", tipoDieta=" + tipoDieta + '}';
    }

    
    
   
    
    
    
}
